/**
 * Keypad.c
 *
 *  Created on: Apr 30 2024
 *  Author : Hadeer Sherif  sec: 2   BN: 45
 *           Mariam Hatem   sec: 2   BN: 28
 */
#include "Keypad.h"
#include "Gpio.h"
#include "Std_Types.h"

static uint8 previousKey = 0;
static uint8 currentKey = 0;

void Keypad_Init(void)
{
    uint8 index = 0;
    // config columns
    for(index = COL_START_INDEX; index <= COL_END_INDEX; index ++){
        Gpio_ConfigPin(COL_PORT, index, GPIO_INPUT, GPIO_PULL_UP);
    }

    //config rows output
    for(index=ROw_START_INDEX;index<=ROW_END_INDEX;index++){
    	Gpio_ConfigPin(ROW_PORT, index, GPIO_OUTPUT, GPIO_PUSH_PULL);
    }


    // put ideal state for output pins =>all rows will be high
    for(index=ROw_START_INDEX;index<=ROW_END_INDEX;index++){
        	Gpio_WritePin(ROW_PORT,index, HIGH);
        }

}


//function to manage the keypad
void Keypad_Manange(void){
	// Variables for iterating over rows and columns, and storing the pressed key
	uint8 row_iterator;
	uint8 col_iterator;
	uint8 key=0;

	// Loop through each row of the keypad matrix
	for(row_iterator=ROw_START_INDEX;row_iterator<=ROW_END_INDEX;row_iterator++){

		// Set the current row to LOW to scan for key presses
		Gpio_WritePin(ROW_PORT,row_iterator, LOW);
		// Loop through each column of the keypad matrix
		for(col_iterator=COL_START_INDEX;col_iterator<=COL_END_INDEX;col_iterator++){
			// Check if the current column reads LOW, indicating a pressed key
			if(!(Gpio_ReadPin(COL_PORT,col_iterator))){
				// Determine the pressed key based on the row and column index
				key=array[row_iterator-ROw_START_INDEX][col_iterator-COL_START_INDEX];
				// Check if the pressed key is different from the previously stored key
				if (key != previousKey) {
					// Store the new pressed key
					previousKey = key;
					currentKey = key;
					// Call the notification function to handle the key press event
					KeypadCallout_KeyPressNotificaton();
				}
				break;
			}
		}
		// Restore the row to HIGH for the next iteration
		Gpio_WritePin(ROW_PORT,row_iterator, HIGH);
	}

}

// Function to retrieve the last stored key
uint8 Keypad_GetKey(void){
	return currentKey;
}

