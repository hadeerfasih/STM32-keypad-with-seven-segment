
/**
 * Keypad.h
 *
 *  Created on: Thu Apr 27 2023
 *  Author    : Abdullah Darwish
 */

#ifndef KEYPAD_H
#define KEYPAD_H

#include "Gpio.h"

/**
 * Keypad.h
 *
 *  Created on: Apr 30 2024
 *  Author : Hadeer Sherif  sec: 2   BN: 45
 *           Mariam Hatem   sec: 2   BN: 28
 */

// Define the GPIO port and pin indices for the keypad columns
#define COL_PORT  GPIO_B
#define COL_START_INDEX 0
#define COL_END_INDEX 2

// Define the GPIO port and pin indices for the keypad rows
#define ROW_PORT GPIO_B
#define ROw_START_INDEX 5
#define ROW_END_INDEX 8

// Define the array to store the keypad matrix
extern uint8 array[4][3];



// Function declarations for the keypad manager API

// Function to initialize the keypad
void Keypad_Init(void);

// Function to manage the keypad and detect key presses
void Keypad_Manange(void);

// Function to retrieve the last stored key
uint8 Keypad_GetKey(void);


// Function declaration for the application to handle key press notifications
void KeypadCallout_KeyPressNotificaton(void);


#endif /* KEYPAD_H */
