/**
 * Gpio_Private.h
 *
 *  Created on: Apr 30 2024
 *  Author : Hadeer Sherif  sec: 2   BN: 45
 *           Mariam Hatem   sec: 2   BN: 28
 */


#ifndef GPIO_PRIVATE_H
#define GPIO_PRIVATE_H
#include "Utils.h"

#define GPIOA_BASE_ADDR    0x40020000
#define GPIOB_BASE_ADDR    0x40020400

#define GPIOX_MODER        (0x00)
#define GPIOX_OTYPER       (0x04)
#define GPIOX_OSPEEDR      (0x08)
#define GPIOX_PUPDR        (0x0C)
#define GPIOX_IDR          (0x10)
#define GPIOX_ODR          (0x14)
#define GPIOX_BSRR         (0x18)
#define GPIOX_LCKR         (0x1C)
#define GPIOX_AFRL         (0x20)
#define GPIOX_AFRH         (0x24)



#endif /* GPIO_PRIVATE_H */
