/**
 * Gpio.c
 *
 *  Created on: Apr 30 2024
 *  Author : Hadeer Sherif  sec: 2   BN: 45
 *           Mariam Hatem   sec: 2   BN: 28
 */

#include "Gpio.h"
#include "Gpio_Private.h"
#include "Std_Types.h"

#define GPIO_REG(REG_ID,PORT_ID)   ((uint32 *)((REG_ID) + (PORT_ID)))
uint32 gpioAddresses[2]={GPIOA_BASE_ADDR,GPIOB_BASE_ADDR};


void Gpio_ConfigPin(uint8 PortName, uint8 PinNum, uint8 PinMode,uint8 DefaultState)
{
	uint8 OutputState = DefaultState & 0x1;
	uint8 InputState = DefaultState >> 1;

	uint8 PortId=PortName-GPIO_A;
	uint32 *gpioModer=GPIO_REG(GPIOX_MODER,gpioAddresses[PortId]);
	uint32 *gpioOutputTypeReg=GPIO_REG(GPIOX_OTYPER,gpioAddresses[PortId]);
	uint32 *gpioPullUpDownReg=GPIO_REG(GPIOX_PUPDR ,gpioAddresses[PortId]);

	*gpioModer&= ~(0x3 << (2 * PinNum));
	*gpioModer|= (PinMode << (2 * PinNum));

	*gpioOutputTypeReg&= ~(0x01 << PinNum);
	*gpioOutputTypeReg|= (OutputState << PinNum);

	*gpioPullUpDownReg&= ~(0x3 << (2 * PinNum));
	*gpioPullUpDownReg|= (InputState << (2 * PinNum));

}

void Gpio_WritePin(uint8 PortName, uint8 PinNum, uint8 Data)
{
	uint8 PortId=PortName-GPIO_A;
	uint32 *gpioOutputDataReg=GPIO_REG(GPIOX_ODR,gpioAddresses[PortId]);
	*gpioOutputDataReg&= ~(0x01 << PinNum);
	*gpioOutputDataReg|= (Data << PinNum);
}

uint8 Gpio_ReadPin(uint8 PortName, uint8 PinNum)
{
	uint8 data = 0;
	uint8 PortId=PortName-GPIO_A;
	uint32 *gpioInputDataReg=GPIO_REG(GPIOX_IDR,gpioAddresses[PortId]);
	data =((*gpioInputDataReg) & (1 << PinNum))>>PinNum;

	return data;
}
